create view V_EMP_10 as
SELECT empno,emname,deptno
FROM emp
WHERE deptno=1
/

